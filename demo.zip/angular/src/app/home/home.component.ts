import { Component, OnInit } from '@angular/core';
import { SeoManagerPro } from 'seo-manager-pro';

@Component({
  selector: 'app-home',
  template: '<h1>Home Page</h1>',
})
export class HomeComponent implements OnInit {
  ngOnInit() {
    SeoManagerPro.updateSeo({
      title: 'Home Page',
      description: 'Welcome to the best site!',
      image: 'https://example.com/image.jpg',
      canonicalUrl: 'https://example.com/home',
      robots: 'index,follow',
      schema: [
        {
          type: 'Product',
          data: {
            name: 'iPhone 15',
            description: 'The best smartphone ever.',
            image: 'https://example.com/iphone.jpg',
            price: 999,
            priceCurrency: 'USD'
          }
        },
        {
          type: 'FAQPage',
          data: {
            mainEntity: [
              {
                '@type': 'Question',
                name: 'Is it waterproof?',
                acceptedAnswer: {
                  '@type': 'Answer',
                  text: 'Yes, it has IP68 rating.'
                }
              }
            ]
          }
        }
      ],
      customMetaTags: [
        { name: 'author', content: 'BestShop' },
        { name: 'keywords', content: 'iphone, smartphone, apple' }
      ]
    });
  }
}
