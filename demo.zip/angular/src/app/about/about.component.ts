import { Component, OnInit } from '@angular/core';
import { SeoManagerPro } from 'seo-manager-pro';

@Component({
  selector: 'app-about',
  template: '<h1>About Page</h1>',
})
export class AboutComponent implements OnInit {
  ngOnInit() {
    SeoManagerPro.updateSeo({
      title: 'About Us',
      description: 'Learn more about us.',
      canonicalUrl: 'https://example.com/about',
      robots: 'index,follow'
    });
  }
}
