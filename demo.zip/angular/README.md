# Angular SEO Demo (v2) with `seo-manager-pro`

This is a simplified Angular demo showing how to use the `seo-manager-pro` package without relying on Angular's Meta or Title services.

## Highlights

- Directly updates the DOM with meta tags, canonical links, and JSON-LD schema.
- Supports multiple types of structured data.
- Fully framework-agnostic and lightweight.

## Installation

```bash
npm install seo-manager-pro
```

## Usage in Angular Components

```ts
import { SeoManagerPro } from 'seo-manager-pro';

SeoManagerPro.updateSeo({
  title: 'Home Page',
  description: 'Welcome to the best site!',
  ...
});
```

## Pages

- Home: includes title, description, image, canonical, custom meta, and schema
- About: includes basic meta info

---
