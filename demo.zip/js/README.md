# Vanilla JavaScript SEO Demo with `seo-manager-pro`

This is a super lightweight example of using `seo-manager-pro` in a plain HTML + JS environment.

## Features

- Direct manipulation of meta tags and title
- Schema.org structured data
- Canonical links and robots control
- No frameworks required!

## How to Run

Just open `index.html` in your browser.
Ensure you're using a local server (e.g. VSCode Live Server or Python's `http.server`) if testing module imports.
