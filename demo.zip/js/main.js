import { SeoManagerPro } from 'seo-manager-pro';

SeoManagerPro.updateSeo({
  title: 'JavaScript SEO Page',
  description: 'This is a vanilla JS page with full SEO setup!',
  image: 'https://example.com/image.jpg',
  canonicalUrl: 'https://example.com/js-seo',
  robots: 'index,follow',
  customMetaTags: [
    { name: 'author', content: 'Vanilla Dev' },
    { name: 'keywords', content: 'javascript, seo, meta tags' }
  ],
  schema: [
    {
      type: 'Article',
      data: {
        headline: 'Simple JS SEO',
        author: 'Jane Smith',
        datePublished: '2024-05-01'
      }
    }
  ]
});
