# React SEO Demo with `seo-manager-pro`

This is a simple React app using `seo-manager-pro` for dynamic SEO management.

## Features

- Dynamic title, meta, canonical, and schema
- Uses `react-router-dom` for routing
- Lightweight and framework-agnostic SEO package

## Installation

```bash
npm install
```

## Run

```bash
npm start
```

## Pages

- `/` — Home page with full SEO data
- `/about` — Simple About page with basic SEO
