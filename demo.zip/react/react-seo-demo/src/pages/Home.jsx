import React, { useEffect } from 'react';
import { SeoManagerPro } from 'seo-manager-pro';

const Home = () => {
  useEffect(() => {
    SeoManagerPro.updateSeo({
      title: 'Home Page',
      description: 'Welcome to our awesome site!',
      image: 'https://example.com/home.jpg',
      canonicalUrl: 'https://example.com/',
      robots: 'index,follow',
      schema: [
        {
          type: 'Article',
          data: {
            headline: 'Welcome Home',
            author: 'John Doe',
            datePublished: '2023-01-01'
          }
        }
      ]
    });
  }, []);

  return <h1>Home Page</h1>;
};

export default Home;
