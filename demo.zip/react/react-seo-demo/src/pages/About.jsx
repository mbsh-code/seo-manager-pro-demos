import React, { useEffect } from 'react';
import { SeoManagerPro } from 'seo-manager-pro';

const About = () => {
  useEffect(() => {
    SeoManagerPro.updateSeo({
      title: 'About Us',
      description: 'Learn more about our team and mission.',
      canonicalUrl: 'https://example.com/about',
      robots: 'index,follow'
    });
  }, []);

  return <h1>About Page</h1>;
};

export default About;
